<?php

include_once LUCENT_CORE_CPT_PATH . '/clients/helper.php';

foreach ( glob( LUCENT_CORE_CPT_PATH . '/clients/dashboard/meta-box/*.php' ) as $module ) {
	include_once $module;
}