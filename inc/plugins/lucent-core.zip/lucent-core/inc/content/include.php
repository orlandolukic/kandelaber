<?php

include_once LUCENT_CORE_INC_PATH . '/content/helper.php';