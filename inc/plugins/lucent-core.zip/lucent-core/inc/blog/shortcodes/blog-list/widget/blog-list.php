<?php

if ( ! function_exists( 'lucent_core_add_blog_list_widget' ) ) {
	/**
	 * Function that add widget into widgets list for registration
	 *
	 * @param array $widgets
	 *
	 * @return array
	 */
	function lucent_core_add_blog_list_widget( $widgets ) {
		$widgets[] = 'LucentCoreBlogListWidget';
		
		return $widgets;
	}
	
	add_filter( 'lucent_core_filter_register_widgets', 'lucent_core_add_blog_list_widget' );
}

if ( class_exists( 'QodeFrameworkWidget' ) ) {
	class LucentCoreBlogListWidget extends QodeFrameworkWidget {
		
		public function map_widget() {
			$this->set_widget_option(
				array(
					'field_type' => 'text',
					'name'       => 'widget_title',
					'title'      => esc_html__( 'Title', 'lucent-core' )
				)
			);
			$widget_mapped = $this->import_shortcode_options( array(
				'shortcode_base' => 'lucent_core_blog_list'
			) );
			
			if ( $widget_mapped ) {
				$this->set_base( 'lucent_core_blog_list' );
				$this->set_name( esc_html__( 'Lucent Blog List', 'lucent-core' ) );
				$this->set_description( esc_html__( 'Display a list of blog posts', 'lucent-core' ) );
			}
		}
		
		public function render( $atts ) {
			$params = $this->generate_string_params( $atts );
			
			echo do_shortcode( "[lucent_core_blog_list $params]" ); // XSS OK
		}
	}
}
