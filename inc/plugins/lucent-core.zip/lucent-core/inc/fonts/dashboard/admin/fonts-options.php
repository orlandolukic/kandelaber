<?php

if ( ! function_exists( 'lucent_core_add_fonts_options' ) ) {
	/**
	 * Function that add options for this module
	 */
	function lucent_core_add_fonts_options() {
		$qode_framework = qode_framework_get_framework_root();

		$page = $qode_framework->add_options_page(
			array(
				'scope'       => LUCENT_CORE_OPTIONS_NAME,
				'type'        => 'admin',
				'slug'        => 'fonts',
				'title'       => esc_html__( 'Fonts', 'lucent-core' ),
				'description' => esc_html__( 'Global Fonts Options', 'lucent-core' ),
				'icon'        => 'fa fa-cog'
			)
		);

		if ( $page ) {
			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_enable_google_fonts',
					'title'         => esc_html__( 'Enable Google Fonts', 'lucent-core' ),
					'default_value' => 'yes',
					'args'          => array(
						'custom_class' => 'qodef-enable-google-fonts'
					)
				)
			);

			$google_fonts_section = $page->add_section_element(
				array(
					'name'       => 'qodef_google_fonts_section',
					'title'      => esc_html__( 'Google Fonts Options', 'lucent-core' ),
					'dependency' => array(
						'show' => array(
							'qodef_enable_google_fonts' => array(
								'values'        => 'yes',
								'default_value' => ''
							)
						)
					)
				)
			);

			$page_repeater = $google_fonts_section->add_repeater_element(
				array(
					'name'        => 'qodef_choose_google_fonts',
					'title'       => esc_html__( 'Google Fonts to Include', 'lucent-core' ),
					'description' => esc_html__( 'Choose Google Fonts which you want to use on your website', 'lucent-core' ),
					'button_text' => esc_html__( 'Add New Google Font', 'lucent-core' )
				)
			);

			$page_repeater->add_field_element( array(
				'field_type'  => 'googlefont',
				'name'        => 'qodef_choose_google_font',
				'title'       => esc_html__( 'Google Font', 'lucent-core' ),
				'description' => esc_html__( 'Choose Google Font', 'lucent-core' ),
				'args'        => array(
					'include' => 'google-fonts'
				)
			) );

			$google_fonts_section->add_field_element(
				array(
					'field_type'  => 'checkbox',
					'name'        => 'qodef_google_fonts_weight',
					'title'       => esc_html__( 'Google Fonts Weight', 'lucent-core' ),
					'description' => esc_html__( 'Choose a default Google Fonts weights for your website. Impact on page load time', 'lucent-core' ),
					'options'     => array(
						'100'  => esc_html__( '100 Thin', 'lucent-core' ),
						'100i' => esc_html__( '100 Thin Italic', 'lucent-core' ),
						'200'  => esc_html__( '200 Extra-Light', 'lucent-core' ),
						'200i' => esc_html__( '200 Extra-Light Italic', 'lucent-core' ),
						'300'  => esc_html__( '300 Light', 'lucent-core' ),
						'300i' => esc_html__( '300 Light Italic', 'lucent-core' ),
						'400'  => esc_html__( '400 Regular', 'lucent-core' ),
						'400i' => esc_html__( '400 Regular Italic', 'lucent-core' ),
						'500'  => esc_html__( '500 Medium', 'lucent-core' ),
						'500i' => esc_html__( '500 Medium Italic', 'lucent-core' ),
						'600'  => esc_html__( '600 Semi-Bold', 'lucent-core' ),
						'600i' => esc_html__( '600 Semi-Bold Italic', 'lucent-core' ),
						'700'  => esc_html__( '700 Bold', 'lucent-core' ),
						'700i' => esc_html__( '700 Bold Italic', 'lucent-core' ),
						'800'  => esc_html__( '800 Extra-Bold', 'lucent-core' ),
						'800i' => esc_html__( '800 Extra-Bold Italic', 'lucent-core' ),
						'900'  => esc_html__( '900 Ultra-Bold', 'lucent-core' ),
						'900i' => esc_html__( '900 Ultra-Bold Italic', 'lucent-core' )
					)
				)
			);

			$google_fonts_section->add_field_element(
				array(
					'field_type'  => 'checkbox',
					'name'        => 'qodef_google_fonts_subset',
					'title'       => esc_html__( 'Google Fonts Style', 'lucent-core' ),
					'description' => esc_html__( 'Choose a default Google Fonts style for your website. Impact on page load time', 'lucent-core' ),
					'options'     => array(
						'latin'        => esc_html__( 'Latin', 'lucent-core' ),
						'latin-ext'    => esc_html__( 'Latin Extended', 'lucent-core' ),
						'cyrillic'     => esc_html__( 'Cyrillic', 'lucent-core' ),
						'cyrillic-ext' => esc_html__( 'Cyrillic Extended', 'lucent-core' ),
						'greek'        => esc_html__( 'Greek', 'lucent-core' ),
						'greek-ext'    => esc_html__( 'Greek Extended', 'lucent-core' ),
						'vietnamese'   => esc_html__( 'Vietnamese', 'lucent-core' )
					)
				)
			);

			$page_repeater = $page->add_repeater_element(
				array(
					'name'        => 'qodef_custom_fonts',
					'title'       => esc_html__( 'Custom Fonts', 'lucent-core' ),
					'description' => esc_html__( 'Add custom fonts', 'lucent-core' ),
					'button_text' => esc_html__( 'Add New Custom Font', 'lucent-core' )
				)
			);

			$page_repeater->add_field_element( array(
				'field_type' => 'file',
				'name'       => 'qodef_custom_font_ttf',
				'title'      => esc_html__( 'Custom Font TTF', 'lucent-core' ),
				'args'       => array(
					'allowed_type' => 'application/octet-stream'
				)
			) );

			$page_repeater->add_field_element( array(
				'field_type' => 'file',
				'name'       => 'qodef_custom_font_otf',
				'title'      => esc_html__( 'Custom Font OTF', 'lucent-core' ),
				'args'       => array(
					'allowed_type' => 'application/octet-stream'
				)
			) );

			$page_repeater->add_field_element( array(
				'field_type' => 'file',
				'name'       => 'qodef_custom_font_woff',
				'title'      => esc_html__( 'Custom Font WOFF', 'lucent-core' ),
				'args'       => array(
					'allowed_type' => 'application/octet-stream'
				)
			) );

			$page_repeater->add_field_element( array(
				'field_type' => 'file',
				'name'       => 'qodef_custom_font_woff2',
				'title'      => esc_html__( 'Custom Font WOFF2', 'lucent-core' ),
				'args'       => array(
					'allowed_type' => 'application/octet-stream'
				)
			) );

			$page_repeater->add_field_element( array(
				'field_type' => 'text',
				'name'       => 'qodef_custom_font_name',
				'title'      => esc_html__( 'Custom Font Name', 'lucent-core' ),
			) );

			// Hook to include additional options after module options
			do_action( 'lucent_core_action_after_page_fonts_options_map', $page );
		}
	}

	add_action( 'lucent_core_action_default_options_init', 'lucent_core_add_fonts_options', lucent_core_get_admin_options_map_position( 'fonts' ) );
}