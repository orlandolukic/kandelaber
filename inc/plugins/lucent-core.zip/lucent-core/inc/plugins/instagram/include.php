<?php

include_once LUCENT_CORE_PLUGINS_PATH . '/instagram/helper.php';
