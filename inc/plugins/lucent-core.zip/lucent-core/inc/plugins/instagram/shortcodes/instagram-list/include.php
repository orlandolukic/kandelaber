<?php
include_once LUCENT_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/helper.php';
include_once LUCENT_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/instagram-list.php';
