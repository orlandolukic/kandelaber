<?php
$title_tag = isset( $title_tag ) && ! empty( $title_tag ) ? $title_tag : 'h2';
$min_price = lucent_core_woo_product_category_min_price($params['category_id']);
if ( lucent_is_installed( 'woocommerce' ) ) {
    $currency = get_woocommerce_currency_symbol();
}
?>
<div class="qodef-category-title-holder">
    <<?php echo esc_attr( $title_tag ); ?> class="woocommerce-loop-category__title" <?php qode_framework_inline_style( $this_shortcode->get_title_styles( $params ) ); ?>>
        <?php echo esc_html( $category_name ); ?>
    </<?php echo esc_attr( $title_tag ); ?>>
    <?php
    if($min_price && $min_price !== 0){ ?>
        <span class="qodef-prod-cat-price-holder">
            <span class="qodef-price-text"><?php esc_html_e('From', 'lucent-core');?></span>
            <span class="qodef-price-with-currency">
                <?php if ( !empty ($currency) ) { ?>
                    <span class="qodef-currency"><?php echo esc_attr($currency); ?></span>
                <?php } ?>
                <span class="qodef-price"><?php echo esc_attr($min_price); ?></span>
            </span>

            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
        </span>
    <?php } ?>
</div>