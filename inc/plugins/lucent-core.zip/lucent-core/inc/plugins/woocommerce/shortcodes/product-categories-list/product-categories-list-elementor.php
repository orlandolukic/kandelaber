<?php

class LucentCoreElementorProductCategoriesList extends LucentCoreElementorWidgetBase {
	
	function __construct( array $data = [], $args = null ) {
		$this->set_shortcode_slug( 'lucent_core_product_categories_list' );
		
		parent::__construct( $data, $args );
	}
}

if ( qode_framework_is_installed( 'woocommerce' ) ) {
	lucent_core_get_elementor_widgets_manager()->register_widget_type( new LucentCoreElementorProductCategoriesList() );
}