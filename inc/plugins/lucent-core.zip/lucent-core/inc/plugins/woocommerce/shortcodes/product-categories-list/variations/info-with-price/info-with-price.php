<?php

if ( ! function_exists( 'lucent_core_add_product_categories_list_variation_info_with_price' ) ) {
    /**
     * Function that add variation layout for this module
     *
     * @param array $variations
     *
     * @return array
     */
    function lucent_core_add_product_categories_list_variation_info_with_price( $variations ) {
        $variations['info-with-price'] = esc_html__( 'Info With Price', 'lucent-core' );

        return $variations;
    }

    add_filter( 'lucent_core_filter_product_categories_list_layouts', 'lucent_core_add_product_categories_list_variation_info_with_price' );
}