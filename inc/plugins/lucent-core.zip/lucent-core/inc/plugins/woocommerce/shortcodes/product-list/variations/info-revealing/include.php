<?php

include_once LUCENT_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-list/variations/info-revealing/info-revealing.php';