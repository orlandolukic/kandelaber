<?php

if ( ! function_exists( 'lucent_core_add_product_categories_list_widget' ) ) {
	/**
	 * Function that add widget into widgets list for registration
	 *
	 * @param array $widgets
	 *
	 * @return array
	 */
	function lucent_core_add_product_categories_list_widget( $widgets ) {
		$widgets[] = 'LucentCoreProductCategoriesListWidget';
		
		return $widgets;
	}
	
	add_filter( 'lucent_core_filter_register_widgets', 'lucent_core_add_product_categories_list_widget' );
}

if ( class_exists( 'QodeFrameworkWidget' ) ) {
	class LucentCoreProductCategoriesListWidget extends QodeFrameworkWidget {
		
		public function map_widget() {
			$widget_mapped = $this->import_shortcode_options( array(
				'shortcode_base' => 'lucent_core_product_categories_list',
				'exclude'        => array(
					'icon_type', 'custom_icon'
				)
			) );
			if( $widget_mapped ) {
				$this->set_base( 'lucent_core_product_categories_list' );
				$this->set_name( esc_html__( 'Lucent Product Categories List', 'lucent-core' ) );
				$this->set_description( esc_html__( 'Add a product categories list element into widget areas', 'lucent-core' ) );
			}
		}
		
		public function render( $atts ) {
			
			$params = $this->generate_string_params( $atts );
			
			echo do_shortcode( "[lucent_core_product_categories_list $params]" ); // XSS OK
		}
	}
}
