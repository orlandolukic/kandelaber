<?php

include_once LUCENT_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-categories-list/variations/info-with-price/info-with-price.php';