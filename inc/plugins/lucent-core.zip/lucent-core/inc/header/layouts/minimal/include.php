<?php

include_once LUCENT_CORE_INC_PATH . '/header/layouts/minimal/helper.php';
include_once LUCENT_CORE_INC_PATH . '/header/layouts/minimal/minimal-header.php';
include_once LUCENT_CORE_INC_PATH . '/header/layouts/minimal/dashboard/admin/minimal-header-options.php';
include_once LUCENT_CORE_INC_PATH . '/header/layouts/minimal/dashboard/meta/minimal-header-meta.php';