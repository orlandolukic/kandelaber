<?php
// Include logo
lucent_core_get_header_logo_image();

// Include main navigation
lucent_core_template_part( 'header', 'templates/parts/navigation' );

// Include widget area one
lucent_core_get_header_widget_area();