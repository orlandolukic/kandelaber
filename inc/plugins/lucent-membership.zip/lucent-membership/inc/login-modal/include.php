<?php

include_once LUCENT_MEMBERSHIP_LOGIN_MODAL_PATH . '/helper.php';

foreach ( glob( LUCENT_MEMBERSHIP_LOGIN_MODAL_PATH . '/*/include.php' ) as $module ) {
	include_once $module;
}